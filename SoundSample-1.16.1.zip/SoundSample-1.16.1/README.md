# SoundSample

Minecraft /playsound command helper datapack

![thumbnail](https://pbs.twimg.com/media/EdwoTVOUMAAjyWt?format=png&name=small)

# Usage

1. Select branch and download the datapack

2. Move the datapack to datapacks folder

3. Run `/function soundsample:_give_book`
